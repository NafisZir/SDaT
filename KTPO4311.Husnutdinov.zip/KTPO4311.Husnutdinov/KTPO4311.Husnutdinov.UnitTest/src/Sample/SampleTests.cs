﻿using NUnit.Framework;

namespace KTPO4311.Husnutdinov.UnitTest.src.Sample
{
    [TestFixture]
    public class SampleTests
    {
        [Test]
        public void Demo()
        {
            Assert.Pass();
        }
    }
}
