﻿using System;

namespace KTPO4311.Husnutdinov.Lib.src.LogAn
{
    public interface IExtensionManager
    {
        bool IsValid(string fileName)
        {
            throw new NotImplementedException();
        }
    }
}
