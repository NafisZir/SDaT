﻿namespace KTPO4311.Husnutdinov.Lib.src.LogAn
{
    public interface IWebService
    {
        public void LogError(string message);
    }
}
