﻿using System;

namespace KTPO4311.Husnutdinov.Lib.src.LogAn
{
    public class WebService : IWebService
    {
        public void LogError(string message)
        {
            throw new NotImplementedException();
        }
    }
}
